import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ExemploDois {
    public static void main(String[] args) {
        System.out.println("Unialfa");
        List<String> listaDeCarros = new ArrayList<>();


        List<String>listadoMenu = Arrays.asList("Cadastrar ", "Alterar", "Sair");
        Scanner leia = new Scanner(System.in);
        System.out.println("Informe o nome do carro");
        listaDeCarros.add((leia.nextLine()));

        if (!listaDeCarros.isEmpty()) System.out.println(listaDeCarros.getFirst());
    }
}

import java.util.Scanner;

public class Exemplo {
    private static String[] modelos = new String[3];

    public static void main(String[] args) {
       cadastroCarro();
       imprimirExtrato();

    }

    private static void cadastroCarro() {
        System.out.println("Garagem Unialfa");


            Scanner leia = new Scanner(System.in);
        int index = 0;
        boolean continuar = false;
        do {

                System.out.println("Informe o modelo do carro");
                modelos[index++] = leia.nextLine();

            if (index < modelos.length) {
                System.out.println("Gostaria de cadastrar outro? [1] SIM");
                continuar = leia.nextLine().equals("1");
           }else{
                System.out.println("Limite de carros atingido!");
                continuar = false;
            }

            }while (continuar);
        System.out.println("Cadastro encerrado!");



    }
    private static void imprimirExtrato(){
        for (int i = 0; i < modelos.length; i++) {

            if (modelos[i] != null)
                System.out.println("Carro " + modelos[i] + " cadastrado!");

        }
    }

}
